"use client";
import PromptGenerator from "./PromptGenerator";
export default function Home() {
  return <PromptGenerator />;
}
